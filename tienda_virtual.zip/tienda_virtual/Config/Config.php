<?php

    // define("BASE_URL", "http://localhost/tienda_virtual/");
    const BASE_URL = "http://localhost/tienda_virtual/";

    date_default_timezone_set('America/Puerto_Rico');

    //variables para connectar al database
    const DB_HOST = "localhost";
    const DB_NAME = "dragonfly_drones";
    const DB_USER = "root";
    const DB_PASSWORD = "";
    const DB_CHARSET = "charset=utf8";


    const SPD = ".";
    const SPM = ",";

    const SMONEY = "$";

    
?>