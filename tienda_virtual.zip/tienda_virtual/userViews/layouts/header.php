<?php

session_start();
//calculateTotalCart();

// function calculateTotalCart(){

//        $total_price = 0;
//        $total_quantity = 0;
  
//       foreach($_SESSION['cart'] as $key => $value){
   
//           $product =  $_SESSION['cart'][$key];
  
//           $price =  $product['product_price'];
//           $quantity = $product['product_quantity'];
  
//           $total_price =  $total_price + ($price * $quantity);
//           $total_quantity = $total_quantity + $quantity;
          
  
//       }
  
//       $_SESSION['total'] = $total_price;
//       $_SESSION['quantity'] = $total_quantity;
  
//   }

//include('../server/connection.php');

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $data['tag_page']?></title>

    <link rel="icon" type="image/png" sizes="16x16" href="Assets/images/logo.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <link rel="stylesheet" type="text/css" href="<?= media();?>/css/style.css">
</head>
<body>

    <!--Navbar-->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 fixed-top">
        <div class="container">
         <img class="logo" src="Assets/images/dragonfly_logo.png" />
         <h2 class="brand">Dragonfly Drones</h2>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse nav-buttons" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
             
              <li class="nav-item">
                <a class="nav-link" href="index">Home</a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="shop">Products</a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="contact">Contact Us</a>
              </li>
              <li class="nav-item">
                <a href="cart">
                    <i class="fas fa-shopping-bag">
                      <?php if(isset($_SESSION['quantity']) && $_SESSION['quantity'] != 0) {?>
                            <span class="cart-quantity"> <?php echo $_SESSION['quantity'];  ?> </span>
                      <?php } ?>  
                    </i>
                  </a>

                <?php if (isset($_SESSION['id'])): ?>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user fa-lg"></i></a>
                    <div class="dropdown-menu">
                    <a  class="dropdown-item" href="account">My Account</a>
                      <a class="dropdown-item" href="allorders">My Orders</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="account/logout" id="logout-btn">Logout</a>
                    </div>
                  </li>
                <?php else: 
                  // if (isset($_SESSION['id']))
                  // {
                  //   $link = 'account';
                  // }
                  // else
                  // {
                  //   $link = 'login2';
                  // }?>
                  <a href="login2"><i class="fas fa-user"></i></a>
                <?php endif ?>
              </li>
               
            </ul>
           
          </div>
        </div>
    </nav>
