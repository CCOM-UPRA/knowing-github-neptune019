<?php include('layouts/header.php'); ?>

<!--Contact-->
<div style="margin: 0; padding: 0;min-height: 100vh;display: flex;flex-direction: column;">
     <div style="flex-grow: 1">
<section id="contact" class="container my-5 py-5">
    <div class="container text-center mt-5">
        <h3>Contact us</h3>
        <hr class="mx-auto">
        <p class="w-50 mx-auto">
            Phone number: <span>+1 (787) 456-7891</span>
        </p>
        <p class="w-50 mx-auto">
            Email address: <span>info@dragonflydrones.com</span>
        </p>
        <p class="w-50 mx-auto">
            We work 24/7 to answer your questions
        </p>
    </div>
</section>
</div>

</div>