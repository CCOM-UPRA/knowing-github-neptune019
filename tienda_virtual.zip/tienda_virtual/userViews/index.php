<?php include('layouts/header.php'); ?>
      <!--Home-->
      <section id="home">
        <div class="container">
          <h5>NEW ARRIVALS</h5>
          <h1>The Best Prices</h1>
          <p>We offers the best drones for the most affordable prices</p>
        </div>
      </section>

<?php include('layouts/footer.php'); ?>