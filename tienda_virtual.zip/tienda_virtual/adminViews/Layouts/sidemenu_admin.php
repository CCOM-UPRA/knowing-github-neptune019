<!-- Sidebar menu --> 
<nav id="sidebar" class="col-md-3 col-lg-2 pt-3 d-md-block bg-light sidebar collapse">
      <div class="position-sticky pt-0 mt-0">
      <div class="sidebar-header">
            <h3>Menu</h3>
        </div>
        <ul class="nav flex-column">

          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>products">
              <span data-feather="shopping-cart"></span>
              Products
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>customers">
              <span data-feather="shopping-cart"></span>
              Customers
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>admins">
              <span data-feather="shopping-cart"></span>
              Admins
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>orders">
              <span data-feather="file"></span>
              Orders
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>Reports/inventoryReport">
              <span data-feather="bar-chart-2"></span>
              Stock Report
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>reports">
              <span data-feather="bar-chart-2"></span>
              Sales Reports
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>help">
              <span data-feather="layers"></span>
              Help
            </a>
          </li>

        </ul>

     
      </div>
    </nav>
