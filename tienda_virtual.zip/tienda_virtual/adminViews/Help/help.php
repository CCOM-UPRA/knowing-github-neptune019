<?php headerAdmin($data); ?>
        

<div class="container-fluid">
  <div class="row" style="min-height: 1000px">
   

  <?php sidemenuAdmin($data); ?>


    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group me-2">
          
          </div>
     
        </div>
      </div>
      <h3 class="text-center mt-5">Help</h3>
        <hr class="mx-auto">

      <div class="container mt-3" id="contact">
        <div class="container text-center mt-5">
          <p>Please contact <span>info@dragonflydrones.com<span></p>
          <p>Please call <span>78745678<span></p>
          </div>
      </div>
   

      </div>
    </main>
  </div>




</div>

<?php footerAdmin($data); ?>
</body>
</html>
