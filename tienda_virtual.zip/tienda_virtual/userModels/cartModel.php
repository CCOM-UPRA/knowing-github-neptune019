<?php

    class cartModel extends Mysql{
        public function __construct()
        {
            parent::__construct();
        }


        


    }
?>